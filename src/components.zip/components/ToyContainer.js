import React, {useState} from "react";
import ToyCard from "./ToyCard";

function ToyContainer({toys}) {
  // const [ toys, setToys ] = useState([])

  const mappedToys = toys.map((toy) => {
    return <ToyCard 
      key={toy.id} 
      toy={toy}
    />
  })

  // useEffect(() => {
  //   fetch("http://localhost:3001/toys")
  //     .then(response => response.json())
  //     .then((allToys) => {
  //       setToys(allToys)
  //     })
  // }, [])

  return (
    <div id="toy-collection">{mappedToys}</div>
  );
}

export default ToyContainer;
